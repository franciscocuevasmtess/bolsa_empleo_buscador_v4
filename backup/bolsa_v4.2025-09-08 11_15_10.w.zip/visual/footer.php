

<footer>
<section id="contact">
            <div class="container">
                <div class="row">
                    <div class="col-sx-12 col-sm-4 text-center">
                        <div class="external-link">
                            <img 
                                src="images/imgob23/elemento_zocalo-GOV-PY.png" class="image wp-image-113  attachment-full size-full" 
                                alt="Tabicón del Gobierno y Trabajo" decoding="async" style="max-width: 100%; height: auto;" 
                               decoding="async" loading="lazy" 
                                 sizes="(max-width: 200px) 100vw, 200px">
                        </div>
                    </div>
    
                    <div class="col-sx-12 col-sm-4">
                        <div class="external-link">			<div class="textwidget"><h3>Informaciones</h3>
                        <p><strong>Dirección</strong>: Avda. Perú esquina Río de Janeiro.</p>
                        <p><strong>Teléfono</strong>:&nbsp;    <a href="https://api.whatsapp.com/send?phone=595983578478" target="_blank">
      <i class="fa fa-whatsapp" style="color: #25D366; margin-right: 8px;"></i>
      (0983) 514951
    </a></p>
                        <p><strong>Correo electrónico</strong>:&nbsp;<a href="mailto:empleapyjoven@mtess.gov.py">empleapyjoven@mtess.gov.py</a></p>
</div>
		</div>                    </div>
    
                    <div class="col-sx-12 col-sm-4 text-center">
                        <div class="widget_text external-link">
                            <div class="textwidget custom-html-widget">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        </footer>

       
        <script src="sweetalert2.all.min.js" crossorigin=""></script>