

<footer>
<section id="contact">
            <div class="container">
                <div class="row">
                    <div class="col-sx-12 col-sm-4 text-center">
                        <div class="external-link">
                            <img 
                                src="images/imgob23/elemento_zocalo-GOV-PY.png" class="image wp-image-113  attachment-full size-full" 
                                alt="Tabicón del Gobierno y Trabajo" decoding="async" style="max-width: 100%; height: auto;" 
                               decoding="async" loading="lazy" 
                                 sizes="(max-width: 200px) 100vw, 200px">
                        </div>
                    </div>
    
                    <div class="col-sx-12 col-sm-4">
                        <div class="external-link">			<div class="textwidget"><h3>Informaciones</h3>
                        <p><strong>Dirección</strong>: Avda. Perú esquina Río de Janeiro.</p>
                        <p><strong>Teléfono</strong>:&nbsp;<a href="tel:+59521 7290100">(+595 21) 729 0100</a></p>
                        <p><strong>Correo electrónico</strong>:&nbsp;<a href="mailto:emplea@mtess.gov.py">emplea@mtess.gov.py</a></p>
</div>
		</div>                    </div>
    
                    <div class="col-sx-12 col-sm-4 text-center">
                        <div class="widget_text external-link">
                            <div class="textwidget custom-html-widget">
                                <!--<iframe title="Conectividad" width="315" height="200" src="https://www.youtube.com/embed/MPxeRSUfik4" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen=""></iframe>
                                -->
                                </div>
                                </div>
                                </div>
                </div>
            </div>
        </section>
        <!--
        <section id="powered-by">
            <div class="container text-center pt-3 pb-3">
                <p>
                    <a href="https://www.paraguay.gov.py/guia-estandar" target="_blank"><span style="color:#ffffff">Basado en la Guía estándar para sitios web del Gobierno</span></a>
                </p>
            </div>
        </section>
        -->
        </footer>
   <!--      <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"  crossorigin=""></script>
     <link rel="stylesheet" href="plugin_leaflet/leaflet.css" crossorigin=""/>
        <script src="jquery.masknumber.min.js"></script>
        <script src="plugin_leaflet/leaflet.js" crossorigin=""></script>
        -->
        
       
        <script src="sweetalert2.all.min.js" crossorigin=""></script>